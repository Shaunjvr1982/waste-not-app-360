# UI/UX Wireframes

This directory contains early-stage wireframes and design notes for the Food Waste Tracker application.

## Key Screens

1. **Login / Authentication**
    - Role-based entry (Steward, Chef, Manager, Admin)

2. **Main Dashboard**
    - Quick summary: Today's waste, alerts, recent entries

3. **Waste Entry**
    - 120L bin slider, weight entry, photo upload, waste type selector (color-coded)
    - Confirmation and review for Chefs/Managers

4. **Analytics & Reports**
    - Daily/weekly/monthly breakdown
    - Waste stream types, location comparisons, cost impact

5. **Admin Panel**
    - Feature toggles, user/role management, settings

## How to Update

- Add wireframes as image files (`.png`, `.svg`, etc.) or export from Figma/Sketch/Draw.io
- Include brief descriptions or user flow notes
- Example file: `bin_entry_wireframe.png`

---

## Example List

- `login_wireframe.png`
- `dashboard_wireframe.png`
- `bin_entry_wireframe.png`
- `admin_panel_wireframe.png`
- `reporting_wireframe.png`
