# SOP: Staff Training for Food Waste Tracker

## Objective

Ensure all relevant staff understand the system and their responsibilities.

## Training Topics

- Logging in and selecting correct role
- Entering bin volumes and waste types
- Using photo upload and understanding AI suggestions
- Reviewing and editing entries (for Chefs/Managers)
- Understanding reports and alerts
- Data privacy and hygiene best practices

## Format

- 1-hour workshop per location
- Reference: [bin-filling-estimate.md](bin-filling-estimate.md)
- Ongoing support via chat or helpdesk

## Checklist

- [ ] Staff can log in and access the system
- [ ] Staff understand bin types and color codes
- [ ] Staff can use the app for entries and uploads
- [ ] Managers know how to approve/edit entries
- [ ] All staff aware of privacy and data handling

---

## Revision History

- v1.0 (2025-05-16): Initial draft
