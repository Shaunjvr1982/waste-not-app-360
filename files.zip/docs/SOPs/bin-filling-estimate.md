# SOP: Bin Filling Estimate

## Purpose

Standardize bin fill-level estimation for consistent waste recording.

## Steps

1. **Visual Reference**
    - Bins have internal markings at 25%, 50%, 75%, and 100%.
    - Use provided chart or app slider to assist estimation.

2. **Procedure**
    - Before emptying a bin, estimate fill level using markings or the app slider.
    - If unsure, take a photo—let the AI suggest a percentage.

3. **Entry**
    - Steward enters fill level via slider or manual weight.
    - Optional: Upload bin photo for AI verification.

4. **Review**
    - Chef or Unit Manager reviews entries at end of shift.

## Tips

- Periodically calibrate your visual estimate with actual weighed bins.
- Use team training sessions for consistency.

---

## Revision History

- v1.0 (2025-05-16): Initial draft
